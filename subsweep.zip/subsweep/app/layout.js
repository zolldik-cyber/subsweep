import "./globals.css";

export const metadata = {
  title: "SubSweep — راقب اشتراكاتك",
  description: "تعرف وين تروح فلوس شركتك التقنية، قبل ما تروح.",
};

export default function RootLayout({ children }) {
  return (
    <html lang="ar" dir="rtl">
      <head>
        <link
          href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;500;700;900&family=JetBrains+Mono:wght@400;600;700&display=swap"
          rel="stylesheet"
        />
      </head>
      <body>{children}</body>
    </html>
  );
}
