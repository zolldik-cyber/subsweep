"use client";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { Plus, Trash2, AlertTriangle, X, LogOut } from "lucide-react";
import { supabase } from "@/lib/supabaseClient";
import { analyzeSubscriptions, daysUntil, fmt } from "@/lib/subscriptions";

const COLORS = ["#6c5ce7", "#e8b84b", "#3ecf8e", "#ff6b5b", "#4fd1c5", "#5b8def", "#c26bd9"];

function futureDate(days) {
  const d = new Date();
  d.setDate(d.getDate() + days);
  return d.toISOString().slice(0, 10);
}

export default function Dashboard() {
  const router = useRouter();
  const [userId, setUserId] = useState(null);
  const [subs, setSubs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [error, setError] = useState("");
  const [form, setForm] = useState({
    name: "",
    price: "",
    cycle: "monthly",
    renewal_date: futureDate(30),
    last_used_days_ago: "",
  });

  useEffect(() => {
    (async () => {
      const { data } = await supabase.auth.getSession();
      if (!data.session) {
        router.replace("/login");
        return;
      }
      setUserId(data.session.user.id);
      await loadSubs();
      setLoading(false);
    })();
  }, [router]);

  async function loadSubs() {
    const { data, error } = await supabase
      .from("subscriptions")
      .select("*")
      .order("created_at", { ascending: false });
    if (!error) setSubs(data || []);
  }

  async function addSub(e) {
    e.preventDefault();
    if (!form.name.trim() || !form.price) {
      setError("عبّي اسم الاشتراك والسعر على الأقل");
      return;
    }
    const { data: sessionData } = await supabase.auth.getSession();
    const { error } = await supabase.from("subscriptions").insert({
      user_id: sessionData.session.user.id,
      name: form.name.trim(),
      price: Number(form.price),
      cycle: form.cycle,
      renewal_date: form.renewal_date,
      last_used_days_ago: form.last_used_days_ago === "" ? 0 : Number(form.last_used_days_ago),
    });
    if (error) {
      setError(error.message);
      return;
    }
    setForm({ name: "", price: "", cycle: "monthly", renewal_date: futureDate(30), last_used_days_ago: "" });
    setError("");
    setShowForm(false);
    loadSubs();
  }

  async function removeSub(id) {
    await supabase.from("subscriptions").delete().eq("id", id);
    setSubs((prev) => prev.filter((s) => s.id !== id));
  }

  async function signOut() {
    await supabase.auth.signOut();
    router.replace("/login");
  }

  if (loading) {
    return (
      <div style={{ minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", color: "var(--muted)" }}>
        يحمّل...
      </div>
    );
  }

  const { enriched, total, wasted, usedPct, wastedPct } = analyzeSubscriptions(subs);
  const trialAlerts = enriched.filter((s) => {
    const d = daysUntil(s.renewal_date);
    return d !== null && d <= 3 && d >= 0;
  });

  return (
    <div style={{ maxWidth: 720, margin: "0 auto", padding: "28px 20px 60px" }}>
      {/* header */}
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 24 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <div
            style={{
              width: 34,
              height: 34,
              borderRadius: 9,
              background: "linear-gradient(135deg, var(--amber), var(--coral))",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              fontWeight: 900,
              color: "#14161a",
            }}
          >
            S
          </div>
          <span style={{ fontWeight: 900, fontSize: 19 }}>SubSweep</span>
        </div>
        <div style={{ display: "flex", gap: 8 }}>
          <button onClick={signOut} style={ghostBtn}>
            <LogOut size={13} /> خروج
          </button>
          <button onClick={() => setShowForm((v) => !v)} style={primaryBtn}>
            <Plus size={16} /> إضافة اشتراك
          </button>
        </div>
      </div>

      {/* form */}
      {showForm && (
        <form onSubmit={addSub} style={{ background: "var(--surface)", border: "1px solid var(--line)", borderRadius: 18, padding: 20, marginBottom: 20 }}>
          <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 16 }}>
            <span style={{ fontWeight: 700, fontSize: 14 }}>اشتراك جديد</span>
            <button type="button" onClick={() => setShowForm(false)} style={{ background: "none", border: "none", color: "var(--muted)", cursor: "pointer" }}>
              <X size={18} />
            </button>
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12, marginBottom: 12 }}>
            <div style={{ gridColumn: "span 2" }}>
              <label style={label}>اسم الاشتراك</label>
              <input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="مثلاً: Notion" style={input} />
            </div>
            <div>
              <label style={label}>السعر ($)</label>
              <input type="number" value={form.price} onChange={(e) => setForm({ ...form, price: e.target.value })} placeholder="20" style={input} />
            </div>
            <div>
              <label style={label}>دورة الدفع</label>
              <select value={form.cycle} onChange={(e) => setForm({ ...form, cycle: e.target.value })} style={input}>
                <option value="monthly">شهريًا</option>
                <option value="yearly">سنويًا</option>
              </select>
            </div>
            <div>
              <label style={label}>تاريخ التجديد القادم</label>
              <input type="date" value={form.renewal_date} onChange={(e) => setForm({ ...form, renewal_date: e.target.value })} style={input} />
            </div>
            <div>
              <label style={label}>آخر استخدام (قبل كم يوم)</label>
              <input type="number" value={form.last_used_days_ago} onChange={(e) => setForm({ ...form, last_used_days_ago: e.target.value })} placeholder="0" style={input} />
            </div>
          </div>
          {error && <p style={{ color: "var(--coral)", fontSize: 12.5, marginBottom: 10 }}>{error}</p>}
          <button type="submit" style={{ ...primaryBtn, width: "100%", justifyContent: "center" }}>حفظ الاشتراك</button>
        </form>
      )}

      {/* hero */}
      <div style={{ background: "var(--surface)", border: "1px solid var(--line)", borderRadius: 18, padding: 24, marginBottom: 16 }}>
        <div style={{ color: "var(--muted)", fontSize: 14, marginBottom: 6 }}>إجمالي هذا الشهر</div>
        <div className="mono" style={{ fontSize: 40, fontWeight: 700 }}>
          ${fmt(total)} <span style={{ color: "var(--muted)", fontSize: 18, fontFamily: "Tajawal" }}>/ شهريًا</span>
        </div>
        <div style={{ marginTop: 18 }}>
          <div style={{ display: "flex", justifyContent: "space-between", fontSize: 12, color: "var(--muted)", marginBottom: 7 }}>
            <span>مستخدم فعليًا</span>
            <span>هدر محتمل</span>
          </div>
          <div style={{ height: 10, borderRadius: 6, overflow: "hidden", display: "flex", background: "var(--surface-2)" }}>
            <div style={{ width: `${usedPct}%`, background: "var(--teal)" }} />
            <div style={{ width: `${wastedPct}%`, background: "var(--coral)" }} />
          </div>
          <div style={{ fontSize: 12.5, color: "var(--muted)", marginTop: 8 }}>
            تقدر توفر تقريبًا <b className="mono" style={{ color: "var(--coral)" }}>${fmt(wasted)}</b> شهريًا لو نظّفت المكرر وغير المستخدم.
          </div>
        </div>
      </div>

      {/* trial alerts */}
      {trialAlerts.map((s) => (
        <div key={s.id} style={{ background: "rgba(232,184,75,0.08)", border: "1px solid rgba(232,184,75,0.35)", borderRadius: 14, padding: "12px 16px", marginBottom: 10, display: "flex", gap: 10, alignItems: "center", fontSize: 13.5 }}>
          <AlertTriangle size={16} color="#e8b84b" style={{ flexShrink: 0 }} />
          <span>
            <b style={{ color: "var(--amber)" }}>{s.name}</b> يتجدد خلال {daysUntil(s.renewal_date)} يوم بمبلغ{" "}
            <span className="mono">${fmt(s.price)}</span>.
          </span>
        </div>
      ))}

      {/* list */}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", margin: "26px 0 12px" }}>
        <h2 style={{ fontSize: 15, fontWeight: 700 }}>الاشتراكات النشطة</h2>
        <span style={{ color: "var(--muted)", fontSize: 12.5 }}>{subs.length} اشتراكات</span>
      </div>

      {enriched.length === 0 && (
        <div style={{ color: "var(--muted)", border: "1px dashed var(--line)", borderRadius: 14, padding: 30, textAlign: "center", fontSize: 13.5 }}>
          ما عندك اشتراكات مضافة بعد. اضغط "إضافة اشتراك" وابدأ.
        </div>
      )}

      {enriched.map((s, i) => (
        <div key={s.id} style={{ background: "var(--surface)", border: "1px solid var(--line)", borderRadius: 14, padding: "13px 16px", marginBottom: 8, display: "flex", alignItems: "center", gap: 12 }}>
          <div style={{ width: 38, height: 38, borderRadius: 10, background: COLORS[i % COLORS.length], flexShrink: 0, display: "flex", alignItems: "center", justifyContent: "center", fontWeight: 700, fontSize: 13, color: "#14161a" }}>
            {s.name.slice(0, 2)}
          </div>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ fontWeight: 700, fontSize: 14, marginBottom: 3 }}>{s.name}</div>
            <div style={{ color: "var(--muted)", fontSize: 12, display: "flex", gap: 8, flexWrap: "wrap", alignItems: "center" }}>
              <span>يتجدد خلال {daysUntil(s.renewal_date)} يوم</span>
              {s.isDuplicate && <span style={{ background: "rgba(78,209,197,0.14)", color: "var(--teal)", borderRadius: 20, padding: "2px 8px", fontSize: 11, fontWeight: 700 }}>اشتراك مكرر</span>}
              {s.isUnused && <span style={{ background: "rgba(255,107,91,0.14)", color: "var(--coral)", borderRadius: 20, padding: "2px 8px", fontSize: 11, fontWeight: 700 }}>غير مستخدم</span>}
            </div>
          </div>
          <div style={{ textAlign: "left", flexShrink: 0 }}>
            <div className="mono" style={{ fontSize: 14, fontWeight: 700 }}>${fmt(s.price)}</div>
            <div style={{ color: "var(--muted)", fontSize: 11 }}>{s.cycle === "monthly" ? "شهريًا" : "سنويًا"}</div>
          </div>
          <button onClick={() => removeSub(s.id)} style={{ background: "none", border: "none", color: "var(--muted)", cursor: "pointer", flexShrink: 0 }}>
            <Trash2 size={16} />
          </button>
        </div>
      ))}

      <p style={{ color: "var(--muted)", textAlign: "center", fontSize: 12, marginTop: 34 }}>
        SubSweep — تعرف وين تروح فلوس شركتك التقنية، قبل ما تروح.
      </p>
    </div>
  );
}

const label = { fontSize: 12, color: "var(--muted)", display: "block", marginBottom: 5 };
const input = {
  width: "100%",
  background: "var(--surface-2)",
  border: "1px solid var(--line)",
  color: "var(--text)",
  borderRadius: 10,
  padding: "9px 12px",
  fontSize: 13.5,
};
const primaryBtn = {
  background: "var(--amber)",
  color: "#14161a",
  border: "none",
  borderRadius: 10,
  padding: "10px 16px",
  fontWeight: 700,
  fontSize: 13.5,
  cursor: "pointer",
  display: "flex",
  alignItems: "center",
  gap: 6,
};
const ghostBtn = {
  background: "var(--surface)",
  border: "1px solid var(--line)",
  color: "var(--muted)",
  borderRadius: 10,
  padding: "10px 14px",
  fontSize: 12.5,
  cursor: "pointer",
  display: "flex",
  alignItems: "center",
  gap: 6,
};
