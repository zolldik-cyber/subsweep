"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { supabase } from "@/lib/supabaseClient";

export default function LoginPage() {
  const router = useRouter();
  const [mode, setMode] = useState("signin"); // signin | signup
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [info, setInfo] = useState("");
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e) {
    e.preventDefault();
    setError("");
    setInfo("");
    setLoading(true);

    if (mode === "signup") {
      const { error } = await supabase.auth.signUp({ email, password });
      setLoading(false);
      if (error) return setError(error.message);
      setInfo("تم إنشاء الحساب. تحقق من بريدك لتأكيد الحساب ثم سجّل دخولك.");
      setMode("signin");
      return;
    }

    const { error } = await supabase.auth.signInWithPassword({ email, password });
    setLoading(false);
    if (error) return setError(error.message);
    router.push("/dashboard");
  }

  return (
    <div
      style={{
        minHeight: "100vh",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        padding: 20,
      }}
    >
      <form
        onSubmit={handleSubmit}
        style={{
          background: "var(--surface)",
          border: "1px solid var(--line)",
          borderRadius: 18,
          padding: 28,
          width: "100%",
          maxWidth: 380,
        }}
      >
        <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 22 }}>
          <div
            style={{
              width: 34,
              height: 34,
              borderRadius: 9,
              background: "linear-gradient(135deg, var(--amber), var(--coral))",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              fontWeight: 900,
              color: "#14161a",
            }}
          >
            S
          </div>
          <span style={{ fontWeight: 900, fontSize: 19 }}>SubSweep</span>
        </div>

        <h1 style={{ fontSize: 16, fontWeight: 700, marginBottom: 4 }}>
          {mode === "signin" ? "سجّل دخولك" : "أنشئ حساب جديد"}
        </h1>
        <p style={{ color: "var(--muted)", fontSize: 13, marginBottom: 20 }}>
          راقب اشتراكاتك واعرف وين تروح فلوسك.
        </p>

        <label style={{ fontSize: 12, color: "var(--muted)" }}>البريد الإلكتروني</label>
        <input
          type="email"
          required
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          style={inputStyle}
        />

        <label style={{ fontSize: 12, color: "var(--muted)" }}>كلمة المرور</label>
        <input
          type="password"
          required
          minLength={6}
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          style={inputStyle}
        />

        {error && <p style={{ color: "var(--coral)", fontSize: 12.5, marginBottom: 10 }}>{error}</p>}
        {info && <p style={{ color: "var(--teal)", fontSize: 12.5, marginBottom: 10 }}>{info}</p>}

        <button
          type="submit"
          disabled={loading}
          style={{
            background: "var(--amber)",
            color: "#14161a",
            border: "none",
            borderRadius: 10,
            padding: "11px 0",
            width: "100%",
            fontWeight: 700,
            fontSize: 14,
            cursor: "pointer",
            marginTop: 6,
          }}
        >
          {loading ? "يشتغل..." : mode === "signin" ? "دخول" : "إنشاء حساب"}
        </button>

        <p style={{ fontSize: 12.5, color: "var(--muted)", textAlign: "center", marginTop: 16 }}>
          {mode === "signin" ? "ما عندك حساب؟ " : "عندك حساب؟ "}
          <button
            type="button"
            onClick={() => setMode(mode === "signin" ? "signup" : "signin")}
            style={{ background: "none", border: "none", color: "var(--amber)", cursor: "pointer", fontWeight: 700 }}
          >
            {mode === "signin" ? "أنشئ وحد" : "سجّل دخولك"}
          </button>
        </p>
      </form>
    </div>
  );
}

const inputStyle = {
  display: "block",
  width: "100%",
  background: "var(--surface-2)",
  border: "1px solid var(--line)",
  color: "var(--text)",
  borderRadius: 10,
  padding: "10px 12px",
  fontSize: 14,
  marginTop: 5,
  marginBottom: 16,
};
