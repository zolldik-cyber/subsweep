-- شغّل هذا الكود كامل داخل Supabase: SQL Editor > New Query > Run

create table if not exists subscriptions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) not null default auth.uid(),
  name text not null,
  price numeric not null,
  cycle text not null default 'monthly',
  renewal_date date,
  last_used_days_ago integer default 0,
  created_at timestamptz default now()
);

alter table subscriptions enable row level security;

create policy "select_own_subscriptions"
  on subscriptions for select
  using (auth.uid() = user_id);

create policy "insert_own_subscriptions"
  on subscriptions for insert
  with check (auth.uid() = user_id);

create policy "update_own_subscriptions"
  on subscriptions for update
  using (auth.uid() = user_id);

create policy "delete_own_subscriptions"
  on subscriptions for delete
  using (auth.uid() = user_id);
